<script>
	/**
	 * XZH-Shortcut 开始
	 */
	const main = plus.android.runtimeMainActivity();
	const Intent = plus.android.importClass("android.content.Intent");
	/**
	 * XZH-Shortcut 结束
	 */
	
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
			
			/**
			 * XZH-Shortcut 开始
			 */
			const intent = main.getIntent();
			const path = intent.getStringExtra("path");// list 里面的 path
			//根据 path路径 进行跳转
			if(path === null) return;
			//使用 $nextTick 延时跳转，避免在 tabBar 页面出现 BUG
			this.$nextTick(function(){
				console.log(path);
				uni.navigateTo({
					url: path,
					success() {
						console.log('成功');
						//移除跳转路径，避免重复跳转
						intent.removeExtra("path");
					},
					fail() {
						console.log('失败');
					}
				});
			})
			/**
			 * XZH-Shortcut 结束
			 */
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	/*每个页面公共css */
</style>
