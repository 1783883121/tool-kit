<template>
	<view class="container">
		<view class="header">
			<image class="back" src="../../static/black-back.png" mode="" @click='back'></image>
		</view>
		<view class="content">
			<ls-swiper @change='change' :list="list" :crown="true" :loop='true' height='130' previousMargin="120" nextMargin='120'>
				<template v-slot="{data}">
					<view class="tab ">
						<image class="tab-img" lazy-load :src="data.imgUrl" mode=""></image>
						<text class="tab-title f-bold f34 lb-6">{{data.label}}</text>
						<view class="tab-tag">{{data.munber}}个推荐地点</view>
					</view>
				</template>
			</ls-swiper>
			<view class="detail">
				<view class="title">
					<text>体验地</text>
				</view>
				<ls-swiper :list="d_list" :dots='true'>
					<template v-slot="{data}">
						<view class="detail-wrap">
							<view class="detail-item" v-for="(item,i) in data" :key='i'>
								<image :src="item.imgUrl" lazy-load mode=""></image>
								<view class="item-text">{{item.label}}</view>
							</view>
						</view>
					</template>
				</ls-swiper>
			</view>
		</view>
	</view>
</template>

<script>
	import lsSwiper from '../../components/ls-swiper/index.vue'
	import api from '../../api/index.js'
	export default {
		components: {
			lsSwiper
		},
		created() {
			this.getList()
		},
		data() {
			return {
				list: [],
				d_list: []
			}
		},
		methods: {
			getList() {
				api.custom().then(res => {
					this.list = res
					this.d_list = res[0].child
					console.log(this.d_list)
				})
			},
			change(data) {
				this.d_list = data.child
			},
			back() {
				uni.navigateTo({
					url: '/pages/index/index',
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.header {
		margin-top: 40rpx;
		display: flex;
		align-items: center;
		height: 80rpx;
		padding-left: 20rpx;
		
		.back{
			width: 30rpx;
			height: 30rpx;
		}
	}

	.content {
		margin-top: 30rpx;
		background-color: #FFFFFF;

		.tab {
			width: 100%;
			height: calc(100% - 20rpx);
			margin-bottom: 20rpx;
			position: relative;
			border-radius: 8rpx;
			background-color: #000;
			box-shadow: 0 0 14rpx 0 rgba(0, 0, 0, 0.1);

			.tab-img {
				width: 100%;
				height: 100%;
				border-radius: 8rpx;
				opacity: 0.6;
				box-shadow: 0 6px 6px rgba(0, 0, 0, .15);
			}

			.tab-title {
				position: absolute;
				top: 70rpx;
				left: 50%;
				transform: translateX(-50%);
				color: #fff;
			}

			.tab-tag {
				position: absolute;
				top: 120rpx;
				left: 50%;
				transform: translateX(-50%);
				padding: 2rpx 16rpx;
				font-size: 20rpx;
				letter-spacing: 2rpx;
				background-color: #FAB714;
				border-radius: 14rpx;
			}
		}

		.detail {
			margin-top: 20rpx;
			padding: 10rpx;

			.title {
				height: 48rpx;
				line-height: 48rpx;
				font-size: 34rpx;
				font-weight: 600;
				color: rgba(32, 39, 47, 1);
				letter-spacing: 4rpx;
				margin-left: 10rpx;
				margin-bottom: 20rpx;
			}

			.detail-wrap {
				display: flex;
				flex-wrap: wrap;
				justify-content: flex-start;
				padding-left: 10rpx;

				.detail-item {
					width: 230rpx;
					margin-right: 10rpx;

					image {
						width: 100%;
						height: 120rpx;
						border-radius: 6rpx;
					}

					.item-text {
						margin-top: 6rpx;
						margin-bottom: 12rpx;
						font-size: 24rpx;
						letter-spacing: 2rpx;
					}
				}
			}
		}
	}
</style>
