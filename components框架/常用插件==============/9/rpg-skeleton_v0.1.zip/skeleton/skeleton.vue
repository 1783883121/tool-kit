<template>
	<view>
		
		<view v-for="(item , index) in [0,1]" :ref="'skeletion'+index" :style="'display:'+(theDisplayValue(index,allReady)?'inherit;':'none;')" >
			<view v-if="index===1?true:!allReady">	
				<slot></slot>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				allReady:false
			};
		},
		computed:{
			
		},
		methods:{
			theDisplayValue:function(index,allReady){
				let returnValue=false;
				if(index===0){
					returnValue=!allReady;
				}else{
					returnValue=allReady;
				}
				return returnValue ;
			},
			
			isReady:function(){
				this.allReady=true;
			},
			justdoit:function(){
				
				let theObj=this.$refs['skeletion0'][0].$el;
			
				this.changeChild(theObj);
			},
			changeChild:function(pObj){
				
				let indexTab=[0];
				let theAgain=true;
				while(theAgain){
					if(indexTab.length===1&&pObj.children<=indexTab[0]){
						//如果当前节点为根节点的最后一个并且该节点无子节点
						//跳出死循环
						break;
					}
					let nowElem=pObj;
					for(let i=0;i<indexTab.length;i++){
						nowElem=nowElem.children[indexTab[i]];
						
					}
					inspect(nowElem,indexTab[indexTab.length-1]);
					if(nowElem.children!==undefined&&nowElem.children.length>0){
						indexTab.push(0);
						inspect(nowElem.children[0],indexTab[indexTab.length-1]);
					}else{
						if(nowElem.parentNode.children.length>indexTab[indexTab.length-1]+1){
							indexTab[indexTab.length-1]+=1;
							inspect(nowElem.parentNode.children[indexTab[indexTab.length-1]],indexTab[indexTab.length-1]);
						}else{
							while(true){
								if(indexTab.length===1&&pObj.children.length<=indexTab[0]+1){
									//如果当前节点为根节点的最后一个并且该节点无子节点
									//跳出死循环
									theAgain=false;
									break;
								}
								indexTab.pop();
								let nowElem=pObj;
								for(let i=0;i<indexTab.length;i++){
									nowElem=nowElem.children[indexTab[i]];
								}
								if(nowElem.parentNode.children.length>indexTab[indexTab.length-1]+1){
									indexTab[indexTab.length-1]+=1;
									inspect(nowElem.parentNode.children[indexTab[indexTab.length-1]],indexTab[indexTab.length-1]);
									break;
								}
							}
						}
					}
				}
				function inspect(obj,indexNumber){
					if(obj!==undefined){
						if(obj.getAttribute('skeleton-class')!==null){
							let classStr=" "+obj.getAttribute('skeleton-class');
							let oldClass=obj.getAttribute('class');
							obj.setAttribute('class',oldClass+classStr);
							
						}
						if(obj.getAttribute('skeleton')!==null){
							
							if(obj.getAttribute('skeleton')==='true'){
								
								let classStr=(obj.getAttribute('class')!==null?(obj.getAttribute('class')+' my-skeleton-class '):(""+' my-skeleton-class'));
								
								obj.setAttribute('class',classStr);
								let objHeight=obj.scrollHeight;
								let objWidth=obj.scrollWidth;
								obj.innerHTML='<div style="width:'+objWidth+'px;height:'+objHeight+'px"></div>'
							}else if(obj.getAttribute('skeleton')==='false'){
								let styleStr=obj.getAttribute('style')!==null?obj.getAttribute('style')+' display:none;':""+' display:none;';
								obj.setAttribute('style',styleStr);
								
							}
						}
						let theTagName=obj.tagName;
						let parentObj=obj.parentNode;
						let theClass=obj.getAttribute('class')===null?'':obj.getAttribute('class');
						let theStyle=obj.style;
						let newObj;
						switch(theTagName){
							case 'UNI-AUDIO':
							case 'UNI-VIDEO':
							case 'UNI-IMAGE':
								newObj=document.createElement('div');
								newObj.setAttribute('class',theClass+' my-skeleton-class');
								newObj.style=theStyle;
								newObj.setAttribute('style','width:'+obj.clientWidth+'px;height:'+obj.clientHeight+'px;');
								parentObj.removeChild(obj);
								if(parentObj.children.length>indexNumber){
									parentObj.insertBefore(newObj,parentObj.children[indexNumber])
								}else if(parentObj.children.length===indexNumber){
									parentObj.appendChild(newObj);
								}
							 break;
							 case 'UNI-TEXT':
								let theText=obj.innerText;
								newObj=document.createElement('div');
								
								let theSpan=obj.children[0];
								let lineNumber=theSpan.scrollHeight;
								let theWidth=theSpan.scrollWidth;
								console.log(theSpan);
								theSpan.innerText="例";
								let rowNumber=theSpan.scrollHeight;
								console.log(lineNumber);
								console.log(rowNumber);
								lineNumber=Math.round(lineNumber/rowNumber);
								console.log(lineNumber);
								let theHtml="";
								for(let j=0;j<lineNumber;j++){
									if(lineNumber===1){
										console.log("haha");
									}
									if(j===lineNumber-1&&lineNumber>1){
										theHtml+='<div class="my-skeleton-class" style="height:'+(rowNumber/3*2)+'px;width:80%;margin:'+(rowNumber/6)+'px 0;"></div>';
									}else{
										theHtml+='<div class="my-skeleton-class" style="height:'+(rowNumber/3*2)+'px;width:'+theWidth+'px;margin:'+(rowNumber/6)+'px 0;"></div>';
									}
								}
								let newObj_other=document.createElement('div');
								newObj_other.innerHTML=theHtml;
								newObj.appendChild(newObj_other);
								newObj.style=theStyle;
								parentObj.removeChild(obj);
								if(parentObj.children.length>indexNumber){
									parentObj.insertBefore(newObj,parentObj.children[indexNumber])
								}else if(parentObj.children.length===indexNumber){
									parentObj.appendChild(newObj);
								}
								break;
						}
					}
				}
			}
			
		}
	}
</script>

<style>

</style>
