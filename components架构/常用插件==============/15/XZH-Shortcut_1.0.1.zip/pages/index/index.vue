<template>
	<view class="content">
		<button @click="Shortcut">添加</button>
		<button @click="update">修改</button>
		<button @click="removeAll">移除</button>
	</view>
</template>

<script>
	// 获取 module
	const SHORTCUT = uni.requireNativePlugin("XZH-Shortcut");
	export default {
		data() {
			return {
				title: 'Hello'
			}
		},
		onLoad() {

		},
		methods: {
			Shortcut() {
				//添加 Shortcuts 方法
				let res = SHORTCUT.addShortcutsModule({
					list: [{
							id: 'test',//必填,不能重复
							icon: 'https://img02.sogoucdn.com/app/a/100520024/3c7bc4419f7e2a6f7d772699891bec5b',//选填,网络图片
							path: '/pages/test/test',//选填,跳转的页面路径
							shortLabel: '',//选填
							title: 'test页'//必填
						},
						{
							id: 'home',
							icon: 'file://' + plus.io.convertLocalFileSystemURL( '/static/logo.png' ),//本地图片,要使用平台绝对路径
							path: '/pages/home/home',
							shortLabel: '',
							title: 'home页'
						}
					]
				})
				
				uni.showToast({
					title: JSON.stringify(res),
					icon: 'none'
				})
			},
			update() {
				//修改 Shortcuts 方法
				let res = SHORTCUT.addShortcutsModule({
					list: [{
							id: 'test',
							icon: '',
							path: 'pages/test/test',
							shortLabel: '',
							title: 'test页'
						}
					]
				})
				
				uni.showToast({
					title: JSON.stringify(res),
					icon: 'none'
				})
			},
			removeAll() {
				//移除 Shortcuts 方法
				let res = SHORTCUT.removeAll();
				
				uni.showToast({
					title: JSON.stringify(res),
					icon: 'none'
				})
			}
		}
	}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
</style>
