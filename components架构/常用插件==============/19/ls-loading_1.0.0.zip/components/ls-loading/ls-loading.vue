<template>
	<view class="loading-wrapper" :class="{'nav': nav, 'tab': tab, 'embed': embed}" hover-stop-propagation
	 @tap.stop.prevent @touchmove.stop.prevent>
		<view class="loading-text">
			<text class="text" v-for="(item, index) in texts" :key="index"
			 :style="{'animation-delay': 112.631578 * (index + 1) + 'ms', 'font-size': fontSize + 'rpx'}">
				{{item}}
			</text>
		</view>
	</view>
</template>

<script>
	/**
	 * ls-loading 页面加载等待loading
	 * @description 通常用于页面数据需要异步加载时，为避免出现数据加载完毕之前页面上出现空数据的尴尬情况，显示loading层作为页面载入过渡
	 * @tutorial lsl
	 * @property {Boolean} nav 是否预留出标题栏的高度 （默认：true）
	 * @property {Boolean} tab 是否预留出tabBar的高度 （默认：false）
	 * @property {Boolean} embed 是否为嵌入模式 （默认：false）
	 * @property {String} text 加载中的文字 （默认：正在加载）
	 * @property {String|Number} fontSize 加载中文字大小 （默认：58, 单位rpx）
	 * @example <ls-loading v-if="pageLoading"></ls-loading>
	 */
	export default {
		name: 'ls-loading',
		props: {
			// 是否预留出标题栏的高度
			nav: {
				type: Boolean,
				default: true
			},
			// 是否预留出tabBar的高度
			tab: {
				type: Boolean,
				default: false
			},
			// 加载中的文字
			text: {
				type: String,
				default: '正在加载'
			},
			// embed 是否为嵌入模式
			embed: {
				type: Boolean,
				default: false
			},
			// 加载中文字大小
			fontSize: {
				type: [String, Number],
				default: 58
			}
		},
		computed: {
			texts() {
				return this.text.split('');
			}
		}
	}
</script>

<style scoped>
	.loading-wrapper {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		z-index: 997;
		background-color: #FFFFFF;
		display: flex;
		align-items: center;
		justify-content: center;
		overflow: hidden;
	}

	.loading-wrapper.nav {
		top: calc(var(--status-bar-height) + 44px);
	}

	.loading-wrapper.tab {
		bottom: 50px;
	}

	.loading-wrapper.embed {
		position: relative;
		margin: auto;
		text-align: center;
		background-color: transparent;
		z-index: 1;
	}

	.loading-text {
		font-weight: 700;
		color: #e8e7e8;
	}

	.loading-text .text {
		animation: text cubic-bezier(0.75, 0, 0.5, 1) 2.6s infinite;
	}

	@keyframes text {
		0% {
			color: #c3c3c3;
		}

		20% {
			color: #e8e7e8;
		}

		100% {
			color: #e8e7e8;
		}
	}
</style>
